# pylint: disable=line-too-long,useless-suppression
# ------------------------------------
# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
# ------------------------------------
"""Customize generated code here.

Follow our quickstart for examples: https://aka.ms/azsdk/python/dpcodegen/python/customize
"""
import os
import logging
from urllib.parse import urlparse
from typing import List, Any, Optional, TYPE_CHECKING
from typing_extensions import Self
from azure.core.tracing.decorator import distributed_trace
from azure.core.credentials import TokenCredential
from azure.ai.agents import AgentsClient
from ._client import AIProjectClient as AIProjectClientGenerated
from .operations import TelemetryOperations
from azure.identity import get_bearer_token_provider
from openai import OpenAI

logger = logging.getLogger(__name__)

_console_logging_enabled: bool = os.environ.get("ENABLE_AZURE_AI_PROJECTS_CONSOLE_LOGGING", "False").lower() in (
    "true",
    "1",
    "yes",
)
if _console_logging_enabled:
    import sys

    # Enable detailed console logs across Azure libraries
    azure_logger = logging.getLogger("azure")
    azure_logger.setLevel(logging.DEBUG)
    azure_logger.addHandler(logging.StreamHandler(stream=sys.stdout))
    # Exclude detailed logs for network calls associated with getting Entra ID token.
    identity_logger = logging.getLogger("azure.identity")
    identity_logger.setLevel(logging.ERROR)
    # Make sure regular (redacted) detailed azure.core logs are not shown, as we are about to
    # turn on non-redacted logs by passing 'logging_enable=True' to the client constructor
    # (which are implemented as a separate logging policy)
    logger = logging.getLogger("azure.core.pipeline.policies.http_logging_policy")
    logger.setLevel(logging.ERROR)


def _patch_user_agent(user_agent: Optional[str]) -> str:
    # All authenticated external clients exposed by this client will have this application id
    # set on their user-agent. For more info on user-agent HTTP header, see:
    # https://azure.github.io/azure-sdk/general_azurecore.html#telemetry-policy
    USER_AGENT_APP_ID = "AIProjectClient"

    if user_agent:
        # If the calling application has set "user_agent" when constructing the AIProjectClient,
        # take that value and prepend it to USER_AGENT_APP_ID.
        patched_user_agent = f"{user_agent}-{USER_AGENT_APP_ID}"
    else:
        patched_user_agent = USER_AGENT_APP_ID

    return patched_user_agent


class AIProjectClient(AIProjectClientGenerated):  # pylint: disable=too-many-instance-attributes
    """AIProjectClient.

    :ivar agents: The AgentsClient associated with this AIProjectClient.
    :vartype agents: azure.ai.agents.AgentsClient
    :ivar connections: ConnectionsOperations operations
    :vartype connections: azure.ai.projects.operations.ConnectionsOperations
    :ivar telemetry: TelemetryOperations operations
    :vartype telemetry: azure.ai.projects.operations.TelemetryOperations
    :ivar evaluations: EvaluationsOperations operations
    :vartype evaluations: azure.ai.projects.operations.EvaluationsOperations
    :ivar datasets: DatasetsOperations operations
    :vartype datasets: azure.ai.projects.operations.DatasetsOperations
    :ivar indexes: IndexesOperations operations
    :vartype indexes: azure.ai.projects.operations.IndexesOperations
    :ivar deployments: DeploymentsOperations operations
    :vartype deployments: azure.ai.projects.operations.DeploymentsOperations
    :ivar red_teams: RedTeamsOperations operations
    :vartype red_teams: azure.ai.projects.operations.RedTeamsOperations
    :param endpoint: Project endpoint. In the form
     "https://your-ai-services-account-name.services.ai.azure.com/api/projects/_project"
     if your Foundry Hub has only one Project, or to use the default Project in your Hub. Or in the
     form "https://your-ai-services-account-name.services.ai.azure.com/api/projects/your-project-name"
     if you want to explicitly specify the Foundry Project name. Required.
    :type endpoint: str
    :param credential: Credential used to authenticate requests to the service. Required.
    :type credential: ~azure.core.credentials.TokenCredential
    :keyword api_version: The API version to use for this operation. Default value is
     "2025-05-15-preview". Note that overriding this default value may result in unsupported
     behavior.
    :paramtype api_version: str
    """

    def __init__(self, endpoint: str, credential: TokenCredential, **kwargs: Any) -> None:

        kwargs.setdefault("logging_enable", _console_logging_enabled)

        self._kwargs = kwargs.copy()
        self._patched_user_agent = _patch_user_agent(self._kwargs.pop("user_agent", None))

        super().__init__(endpoint=endpoint, credential=credential, **kwargs)

        self.telemetry = TelemetryOperations(self)  # type: ignore
        self._agents: Optional[AgentsClient] = None

    @property
    def agents(self) -> AgentsClient:  # type: ignore[name-defined]
        """Get the AgentsClient associated with this AIProjectClient.
        The package azure.ai.agents must be installed to use this property.

        :return: The AgentsClient associated with this AIProjectClient.
        :rtype: azure.ai.agents.AgentsClient
        """
        if self._agents is None:
            self._agents = AgentsClient(
                endpoint=self._config.endpoint,
                credential=self._config.credential,
                user_agent=self._patched_user_agent,
                **self._kwargs,
            )
        return self._agents

    @distributed_trace
    def get_openai_client(
        self, *, api_version: Optional[str] = None, connection_name: Optional[str] = None, **kwargs
    ) -> "OpenAI":  # type: ignore[name-defined]
        """Get an authenticated OpenAI client (from the `openai` package) to use with
        AI models deployed to your AI Foundry Project or connected Azure OpenAI services.

        .. note:: The package `openai` must be installed prior to calling this method.

        :keyword api_version: The Azure OpenAI api-version to use when creating the client. Optional.
         See "Data plane - Inference" row in the table at
         https://learn.microsoft.com/azure/ai-foundry/openai/reference#api-specs. If this keyword
         is not specified, you must set the environment variable `OPENAI_API_VERSION` instead.
        :paramtype api_version: Optional[str]
        :keyword connection_name: Optional. If specified, the connection named here must be of type Azure OpenAI.
         The returned OpenAI client will use the inference URL specified by the connected Azure OpenAI
         service, and can be used with AI models deployed to that service. If not specified, the returned
         OpenAI client will use the inference URL of the parent AI Services resource, and can be used
         with AI models deployed directly to your AI Foundry project.
        :paramtype connection_name: Optional[str]

        :return: An authenticated AzureOpenAI client
        :rtype: ~openai.AzureOpenAI

        :raises ~azure.core.exceptions.ResourceNotFoundError: if an Azure OpenAI connection
         does not exist.
        :raises ~azure.core.exceptions.ModuleNotFoundError: if the `openai` package
         is not installed.
        :raises ValueError: if the connection name is an empty string.
        :raises ~azure.core.exceptions.HttpResponseError:
        """
        if connection_name is not None and not connection_name:
            raise ValueError("Connection name cannot be empty")

        if connection_name:
            # TODO: Restore this functionality
            raise NotImplementedError("Creating OpenAI client without a connection name is not supported")

        # TODO: Test the case where input endpoint URL has "/" at the end
        openai_base_url = self._config.endpoint + "/openai"  # pylint: disable=protected-access

        default_query = {"api-version": "2025-05-15-preview"} if api_version is None else {"api-version": api_version}

        logger.debug(  # pylint: disable=specify-parameter-names-in-call
            "[get_openai_client] Creating OpenAI client using Entra ID authentication, on parent AI Services resource, base url = `%s`, api_version = `%s`",  # pylint: disable=line-too-long
            openai_base_url,
            api_version,
        )

        http_client = None

        if _console_logging_enabled:
            try:
                import httpx
            except ModuleNotFoundError as e:
                raise ModuleNotFoundError("Failed to import httpx. Please install it using 'pip install httpx'") from e

            class OpenAILoggingTransport(httpx.HTTPTransport):

                def _sanitize_auth_header(self, headers):
                    """Sanitize authorization header by redacting sensitive information."""

                    if "authorization" in headers:
                        auth_value = headers["authorization"]
                        if len(auth_value) >= 7:
                            headers["authorization"] = auth_value[:7] + "<REDACTED>"
                        else:
                            headers["authorization"] = "<ERROR>"

                def handle_request(self, request):
                    """
                    Log HTTP request and response details to console, in a nicely formatted way,
                    for OpenAI / Azure OpenAI clients.

                    To use, add `http_client=httpx.Client(transport=OpenAILoggingTransport())` to the client
                    constructor.
                    """

                    print(f"\n==> Request:\n{request.method} {request.url}")
                    headers = dict(request.headers)
                    self._sanitize_auth_header(headers)
                    print("Headers:")
                    for key, value in headers.items():
                        print(f"  {key}: {value}")
                    if request.content:
                        try:
                            print(f"Body:\n  {request.content.decode('utf-8')}")
                        except Exception:
                            print(f"Body (raw):\n  {request.content}")

                    response = super().handle_request(request)

                    print(f"\n<== Response:\n{response.status_code} {response.reason_phrase}")
                    print("Headers:")
                    for key, value in dict(response.headers).items():
                        print(f"  {key}: {value}")
                    try:
                        print(f"Body:\n {response.read().decode('utf-8')}")
                    except Exception:
                        print("Body:\n  [non-text content]")
                    print("\n")

                    return response

            http_client = httpx.Client(transport=OpenAILoggingTransport())

        client = OpenAI(
            # See https://learn.microsoft.com/python/api/azure-identity/azure.identity?view=azure-python#azure-identity-get-bearer-token-provider # pylint: disable=line-too-long
            api_key=get_bearer_token_provider(
                self._config.credential,  # pylint: disable=protected-access
                "https://ai.azure.com/.default",
            ),
            base_url=openai_base_url,
            default_query={"api-version": "2025-05-15-preview"},
            default_headers={"accept-encoding": "deflate"}, # TODO: Remove once service bug related to gzip is fixed
            http_client=http_client,
        )

        return client

    def close(self) -> None:
        if self._agents:
            self.agents.close()
        super().close()

    def __enter__(self) -> Self:
        super().__enter__()
        if self._agents:
            self.agents.__enter__()
        return self

    def __exit__(self, *exc_details: Any) -> None:
        if self._agents:
            self.agents.__exit__(*exc_details)
        super().__exit__(*exc_details)


__all__: List[str] = [
    "AIProjectClient",
]  # Add all objects you want publicly available to users at this package level


def patch_sdk():
    """Do not remove from this file.

    `patch_sdk` is a last resort escape hatch that allows you to do customizations
    you can't accomplish using the techniques described in
    https://aka.ms/azsdk/python/dpcodegen/python/customize
    """
